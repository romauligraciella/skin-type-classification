from flask import Flask, render_template, request
from keras.models import load_model
from PIL import Image
import numpy as np
import cv2

app = Flask(__name__)

# Load Keras model 
def load_h5_model(filepath):
    model = load_model(filepath)  
    return model

model = load_h5_model('skintype-type-81.66.h5') 

@app.route('/')
def home():
    return render_template('home.html')

def predict_image(image_array, model):
    image_array = np.expand_dims(image_array, axis=0)

    # Perform prediction
    predictions = model.predict(image_array)  
    class_index = np.argmax(predictions)  
    # Map the index to the corresponding class label
    labels = ['Oily', 'Normal'] 
    return labels[class_index]

# Define a simple skin detection function using color thresholding
def is_skin_image(image):
    image = np.uint8(image) 

    # Convert the image to HSV color space
    hsv = cv2.cvtColor(image, cv2.COLOR_RGB2HSV)
    
    # Define the range of skin color in HSV 
    lower_skin = np.array([0, 20, 70], dtype=np.uint8)
    upper_skin = np.array([20, 255, 255], dtype=np.uint8)
    
    # Create a mask that identifies skin-like areas
    skin_mask = cv2.inRange(hsv, lower_skin, upper_skin)
    
    # Calculate the percentage of skin pixels in the image
    skin_pixels = np.sum(skin_mask > 0)
    total_pixels = skin_mask.size
    skin_ratio = skin_pixels / total_pixels
    
    # If the ratio of skin pixels is above a threshold, consider it a valid skin image
    return skin_ratio > 0.1  

@app.route('/predict', methods=['POST'])
def predict():
    if 'image' not in request.files:
        return "No file uploaded", 400

    file = request.files['image']
    if file.filename == '':
        return "No file selected", 400

    try:
        image = Image.open(file)
        image_cv = np.array(image.convert('RGB'))

        # Check if the image contains skin
        if not is_skin_image(image_cv):
            return render_template('noskindetected.html'), 400

        # Resize and normalize the image for the model
        image = image.resize((128, 128)) 
        image_array = np.asarray(image) / 255.0  

        # Perform classification using the pre-trained model
        result = predict_image(image_array, model)

        # Return the result to the user
        return render_template('result.html', result=result)
    
    except Exception as e:
        return f"Error processing image: {e}", 500
    

if __name__ == '__main__':
    app.run(debug=True)